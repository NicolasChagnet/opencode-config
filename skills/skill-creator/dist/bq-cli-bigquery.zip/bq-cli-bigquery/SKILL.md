---
name: bq-cli-bigquery
description: This skill should be used when working with BigQuery through the `bq` CLI, especially before running queries that need schema inspection, dry-run cost estimation, or SQL performance review.
---

# Bq Cli BigQuery

Prefer schema-first analysis and dry-run cost estimation before running any query that reads table content.

## When to Use This Skill

Use this skill when querying BigQuery with the `bq` CLI, exploring unfamiliar tables, or reviewing query cost and efficiency.
Use it before scanning large tables, joining multiple datasets, or editing SQL that may be expensive.

## How to Use

1. Inspect table schema and partitioning/cluster metadata before writing the query.
2. Load the BigQuery SQL best-practices reference.
3. Write the query conservatively, selecting only the required columns and filters.
4. Run `bq query --dry_run --use_legacy_sql=false "<query>"` before executing.
5. Read the estimated bytes processed and warn if the query is likely to exceed about 10 GB.
6. If the dry run is expensive, refine filters, reduce scanned columns, and verify partition or cluster pruning.
7. Only execute the query after the cost estimate and query shape are acceptable.
8. Prefer suggestions that reduce scanned bytes, shuffle, and repeated computation.

## References

Load `references/bigquery-bq-cli-best-practices.md` for schema inspection commands, dry-run usage, cost interpretation, and SQL optimization guidance.

## Scripts

No scripts required.

## Assets

No assets required.
